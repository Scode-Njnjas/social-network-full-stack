export const USER_ID_1 = "01927a8d-49fc-702d-bc38-18ff94c47053";
export const USER_ID_2 = "01927a8d-49fc-71a6-a22b-46580cb507f6";
export const USER_ID_3 = "01927a8d-49fc-7285-9c60-370a49051907";
export const USER_ID_4 = "01927a8d-49fc-74bc-bdf9-1d669f6df2cc";
export const USER_ID_5 = "01927a8d-49fc-7685-86d8-625ad74e5d8e";


export const POST_ID_1 = "01927a8d-49fc-7a3d-8b3b-1b3b3b3b3b3b";
export const POST_ID_2 = "01927a8d-49fc-7b1d-8b3b-1b3b3b3b3b3b";
export const POST_ID_3 = "01927a8d-49fc-7b2d-8b3b-1b3b3b3b3b3b";
export const POST_ID_4 = "01927a8d-49fc-7b3d-8b3b-1b3b3b3b3b3b";
export const POST_ID_5 = "01927a8d-49fc-7b4d-8b3b-1b3b3b3b3b3b";


export const REACT_POST_TOPIC = "reaction-post";
export const UN_REACT_POST_TOPIC = "un-reaction-post";

export const RE_POST_COMMENT_TOPIC = "re-post-comment";
export const UN_RE_POST_COMMENT_TOPIC = "un-re-post-comment";

export const REPLY_COMMENT_TOPIC = "reply-comment";
export const DELETE_COMMENT_TOPIC = "delete-comment";

export const EvtChatMessageSent = 'ChatMessageSent';
