export const ErrFollowYourself = new Error('You cannot follow yourself')
export const ErrAlreadyFollowed = new Error('You have already followed this user')
export const ErrFollowNotFound = new Error('Follow relationship not found')
