
export const ErrPostNotFound = new Error('Post not found');
export const ErrPostAlreadySaved = new Error('Post already saved');
export const ErrPostHasNotSaved = new Error('Post has not saved');
