-- AlterTable
ALTER TABLE `notifications` ADD COLUMN `actor_id` VARCHAR(36) NULL;
