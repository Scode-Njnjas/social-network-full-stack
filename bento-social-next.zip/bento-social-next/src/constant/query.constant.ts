export const QUERY_USER_PROFILE_KEY = 'user-profile';
export const QUERY_LIST_POST_BY_USER_ID_KEY = 'list-post-by-user-id';