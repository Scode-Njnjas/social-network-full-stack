export const USER_AVATAR_PLACEHOLDER = '/img/default-avatar.jpg';
