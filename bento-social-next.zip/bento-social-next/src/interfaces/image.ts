export interface IImage {
  url: string;
  alt: string;
  width?: number;
  height?: number;
}
