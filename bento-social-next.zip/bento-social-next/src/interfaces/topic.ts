export interface ITopic {
  id: string;
  name: string;
  color: string;
  postCount: number;
  createdAt: string;
  updatedAt: string;
}
