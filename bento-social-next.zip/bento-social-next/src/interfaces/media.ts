export interface Media {
    filename: string;
    url: string;
    ext: string,
    contentType: string,
    size: number,
}