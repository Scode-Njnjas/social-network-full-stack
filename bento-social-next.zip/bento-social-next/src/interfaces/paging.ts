export interface IPaging {
  page: number;
  limit: number;
  sort: string;
  order: string;
}
