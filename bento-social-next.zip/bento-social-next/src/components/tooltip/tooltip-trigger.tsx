import * as TooltipPrimitive from '@radix-ui/react-tooltip';

//------------------------------------------------------------------------------

const TooltipTrigger = TooltipPrimitive.Trigger;

export { TooltipTrigger };
