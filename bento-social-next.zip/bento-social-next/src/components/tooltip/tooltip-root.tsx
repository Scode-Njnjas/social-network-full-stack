import * as TooltipPrimitive from '@radix-ui/react-tooltip';

//------------------------------------------------------------------------------

const Tooltip = TooltipPrimitive.Root;

export { Tooltip };
