import * as TooltipPrimitive from '@radix-ui/react-tooltip';

//------------------------------------------------------------------------------

const TooltipProvider = TooltipPrimitive.Provider;

export { TooltipProvider };
