import * as AlertDialogPrimitive from '@radix-ui/react-alert-dialog';

// ----------------------------------------------------------------------

const AlertDialog = AlertDialogPrimitive.Root;

export default AlertDialog;
