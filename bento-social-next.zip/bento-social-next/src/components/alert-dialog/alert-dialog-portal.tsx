import * as AlertDialogPrimitive from '@radix-ui/react-alert-dialog';

// ----------------------------------------------------------------------

const AlertDialogPortal = AlertDialogPrimitive.Portal;

export default AlertDialogPortal;
