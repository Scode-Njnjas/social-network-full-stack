import * as AlertDialogPrimitive from '@radix-ui/react-alert-dialog';

// ----------------------------------------------------------------------

const AlertDialogTrigger = AlertDialogPrimitive.Trigger;

export default AlertDialogTrigger;
