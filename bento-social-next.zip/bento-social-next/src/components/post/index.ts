export { default as Post } from './post';
