export { default as TrendingPostCard } from './trending-post-card';
