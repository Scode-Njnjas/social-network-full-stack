export { default as EmptyContent } from './empty-content';
