export interface TabItem {
  key: string;
  label: string;
}
