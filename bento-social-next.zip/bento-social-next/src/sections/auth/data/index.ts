export {
  type LoginData,
  loginSchema,
  type RegisterData,
  registerSchema,
} from './schema';
