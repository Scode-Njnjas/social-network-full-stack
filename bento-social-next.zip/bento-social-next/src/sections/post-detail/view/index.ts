export { default as PostDetailView } from './post-detail-view';
