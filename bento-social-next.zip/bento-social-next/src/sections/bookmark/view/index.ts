export { default as BookmarkView } from './bookmark-view';
