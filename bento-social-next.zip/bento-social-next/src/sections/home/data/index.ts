export { type Post, postSchema } from './schema';
