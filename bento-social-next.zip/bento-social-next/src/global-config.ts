export const HOST_API = process.env.NEXT_PUBLIC_API_DOMAIN;
