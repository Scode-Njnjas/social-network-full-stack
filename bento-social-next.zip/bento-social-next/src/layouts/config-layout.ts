// ----------------------------------------------------------------------

export const HEADER = {
  H_MOBILE: 70,
  H_DESKTOP: 80,
};

export const NAV = {
  W_VERTICAL: 280,
  W_MINI: 88,
};
