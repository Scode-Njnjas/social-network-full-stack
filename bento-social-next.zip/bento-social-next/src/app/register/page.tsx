import { RegisterView } from '@/sections/auth/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Register Page',
};

export default function RegisterPage() {
  return <RegisterView />;
}
