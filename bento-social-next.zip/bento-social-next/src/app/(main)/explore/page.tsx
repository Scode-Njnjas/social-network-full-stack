import React from 'react';

import { ExploreView } from '@/sections/explore/view';

//-----------------------------------------------------------------------------------------------

export default function Explore() {
  return <ExploreView />;
}
