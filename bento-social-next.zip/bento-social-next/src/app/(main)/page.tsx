import HomeView from '@/sections/home/view/home-view';

//-------------------------------------------------------------------------
export const metadata = {
  title: 'Home Page',
};

export default function Home() {
  return (
    <HomeView />
  );
}
