import React from 'react';

import { EditProfileView } from '@/sections/profile/view';

//-------------------------------------------------------------------------

export default function EditProfile() {
  return <EditProfileView />;
}
