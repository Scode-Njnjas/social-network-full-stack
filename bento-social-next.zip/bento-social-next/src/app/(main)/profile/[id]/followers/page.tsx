import React from 'react';

import FollowersView from '@/sections/followers/view/followers-view';

//-------------------------------------------------------------------------

export default function ViewFollower() {
  return <FollowersView />;
}
