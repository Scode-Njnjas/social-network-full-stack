import { ProfileView } from '@/sections/profile/view';
import React from 'react';

export default function Profile() {
  return <ProfileView />;
}
