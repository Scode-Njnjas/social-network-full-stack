import React from 'react';

import NotificationsView from '@/sections/notifications/view/notification-view';

//-----------------------------------------------------------------------------------------------

export default function Notification() {
  return <NotificationsView />;
}
