import { LoginView } from '@/sections/auth/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Login Page',
};

export default function LoginPage() {
  return <LoginView />;
}
