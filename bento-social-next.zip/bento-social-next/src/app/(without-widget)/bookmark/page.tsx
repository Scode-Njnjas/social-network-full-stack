import React from 'react';

import { BookmarkView } from '@/sections/bookmark/view';

//-----------------------------------------------------------------------------------------------

export default function Bookmark() {
  return (
    <BookmarkView />
  );
}
