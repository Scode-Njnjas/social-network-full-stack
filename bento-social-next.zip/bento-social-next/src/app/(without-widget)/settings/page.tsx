import React from 'react';

import SettingsView from '@/sections/settings/view/setting-view';

//-----------------------------------------------------------------------------------------------

export default function page() {
  return <SettingsView />;
}
