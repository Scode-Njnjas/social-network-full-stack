import { MessageView } from '@/sections/message/view';
import React from 'react';

//-----------------------------------------------------------------------------------------------

export default function Messages() {
  return <MessageView />;
}
